# https://realpython.com/pyinstaller-python/#preparing-your-project


from seguid_calculator.calculator import main

if __name__ == '__main__':
    main()
